package com.example.testjni;

import com.example.dt.TestDataStructure;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

	private static final String TAG = "4399SDK-MainActivity";

	//静态JNI方法，并且在通过javah生成了头文件
	private static native String getJniStringA();
	//非静态JNI方法，并且在通过javah生成了头文件
	private native String getJniStringB();
	//静态JNI方法，但是没有通过javah生成了头文件，只是在运行时通过名字协议匹配
	private static native String getJniStringC();
	//动态注册JNI方法
	private static native String nativeGetJniStringD();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		try { 
			System.loadLibrary("testjni");
		} catch(UnsatisfiedLinkError e) {
			Log.d(TAG, "Load testjni error...");
		}
		
//		Log.d(TAG, getJniStringA());
//		Log.d(TAG, getJniStringB());
//		Log.d(TAG, getJniStringC());
//		Log.d(TAG, nativeGetJniStringD());
		
		TestDataStructure tester = new TestDataStructure();
//		tester.testPrimitive();
		tester.testReference();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
