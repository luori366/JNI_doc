package com.example.calljava;

public class Student {
	public static final String TAG = "Student";
	
	public String name;
	private long score;

	public Student(String name, long score) {
		this.name = name;
		this.score = score;
	}

	public long getScore() {
		return score;
	}

	public void setScore(long score) {
		this.score = score;
	}

	public static String getTag() {
		return TAG;
	}
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", score=" + score + "]";
	}
}
