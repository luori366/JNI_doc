package com.example.dt;

import com.example.calljava.Student;

import android.util.Log;

public class TestDataStructure {
	private static final String TAG = "4399SDK-TestDataStructure";
	
	public static boolean ARG_BOOLEAN = true;
	public static byte ARG_BYTE = 'A';
	public static char ARG_CHAR = '好';
	public static short ARG_SHORT = 88;
	public static int ARG_INT = 66;
	public static long ARG_LONG = 655335;
	public static float ARG_FLOAT = 323.82f;
	public static double ARG_DOUBLE = 324234.23532452345;
	
	private static native boolean testJboolean(boolean val);
	private static native byte testJbyte(byte val);
	private static native char testJchar(char val);
	private static native short testJshort(short val);
	private static native int testJint(int val);
	private static native long testJlong(long val);
	private static native float testJfloat(float val);
	private static native double testJdouble(double val);
	
	
	public static String ARG_STRING = "HelloJNI";
	public static String ARG_UNICODE_STRING = "你好jni";
	private static native String testJstring(String val);
	private static native String testUnicode(String val);
	
	public static String ARG_STRING_ARRAY []= {
		"line1",
		"line2",
		"line3"
	};
	
	public static Student ARG_STUDENT_ARRAY [] = {
		new Student("aaaf", 100L),
		new Student("2332", 11L),
		new Student("88", 88L)
	};
	public static String ARG_STRING_MATRIX [][] = {
		{"11af", "12eg", "1aa3"},
		{"adf21", "2aa2", "2asdf3"},
		{"3adfa1", "32", "3afasdf3"}
	};
	
	public int ARG_INT_ARRAY [] = {1, 4, 55, 88};
	private static native String [] testJstringarray(String val []);
	private static native Student [] testJobjectarray(Student val []);
	private static native int [] testArrayRegion(int val []);
	private static native int [] testArrayElements(int val []);
	private static native String [][] testJstringmatrix(String val [][]);
	
	public void testPrimitive() {
		boolean retBoolean = testJboolean(ARG_BOOLEAN);
		Log.d(TAG, "Test Jboolean: " + ARG_BOOLEAN + ", " + retBoolean);
		
		byte retByte = testJbyte(ARG_BYTE);
		Log.d(TAG, "Test Jbyte: " + ARG_BYTE + ", " + retByte);
		
		char retChar = testJchar(ARG_CHAR);
		Log.d(TAG, "Test Jchar: " + ARG_CHAR + ", " + retChar);
		
		short retShort = testJshort(ARG_SHORT);
		Log.d(TAG, "Test Jshort: " + ARG_SHORT + ", " + retShort);
		
		int retInt = testJint(ARG_INT);
		Log.d(TAG, "Test Jint: " + ARG_INT + ", " + retInt);
		
		long retLong = testJlong(ARG_LONG);
		Log.d(TAG, "Test Jlong: " + ARG_LONG + ", " + retLong);
		
		float retFloat = testJfloat(ARG_FLOAT);
		Log.d(TAG, "Test Jfloat: " + ARG_FLOAT + ", " + retFloat);
		
		double retDouble = testJdouble(ARG_DOUBLE);
		Log.d(TAG, "Test Jdouble: " + ARG_DOUBLE + ", " + retDouble);
	}
	
	public void testReference() {
		String retString = testJstring(ARG_STRING);
		Log.d(TAG, "Test jstring: " + ARG_STRING + ", " + retString);
		
		retString = testUnicode(ARG_UNICODE_STRING);
		Log.d(TAG, "Test unicode string: " + ARG_UNICODE_STRING + ", " + retString);
		
		String [] retJstringarray = testJstringarray(ARG_STRING_ARRAY);
		printArray(retJstringarray);
		
		Student [] retJobjectarray = testJobjectarray(ARG_STUDENT_ARRAY);
		printArray(retJobjectarray);
		
		int [] retIntArray = testArrayRegion(ARG_INT_ARRAY);
		for (int i=0; retIntArray!=null && i<retIntArray.length; i++) {
			Log.d(TAG, "[" + i + ", " + retIntArray[i] + "]");
		}
		
		retIntArray = testArrayElements(ARG_INT_ARRAY);
		for (int i=0; retIntArray!=null && i<retIntArray.length; i++) {
			Log.d(TAG, "[" + i + ", " + retIntArray[i] + "]");
		}
		
		String [][] retJstringmatrix = testJstringmatrix(ARG_STRING_MATRIX);
		printMatrix(ARG_STRING_MATRIX);
	}
	
	public <T> void printArray(T array []) {
		if (array == null)
			return;
		
		for (int i=0; i<array.length; i++) {
			Log.d(TAG, "[" + i + ", " + array[i] + "]");
		}
	}
	
	private void printMatrix(String array[][]) {
		for (int i=0; i<array.length; i++) {
			for (int j=0; j<array[i].length; j++) {
				Log.d(TAG, "[" + i + ", " + j + ", " + array[i][j] + "]");
			}
		}
	}
}
