#ifndef UNICODE_STRING_
#define UNICODE_STRING_

#include <jni.h>
#include <string.h>
#include <locale.h>
#include <stdlib.h>

//判断字符串是否unicode字符串
jboolean isASCII(const char * src);

// Unicode字符串->char *
// GetStringChars: Unicode字符串->jchar *
// GetStringUTFChars: Utf-8字符串->char *
char * GetStringUnicodeChars(JNIEnv* env, jstring jsrc, const char * encoding);

//Unicode char * -> jstring
//NewString: jchar * -> jstring
//NewStringUTF: UTF char *-> jstring
jstring NewStringUnicode(JNIEnv * env, const char * src, const char * encoding);
#endif
