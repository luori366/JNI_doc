#include "../include/unicode_string.h"

jclass clazz;
jmethodID methodID;

jboolean isASCII(const char * src) {
	char ch;
	jboolean flag = JNI_TRUE;

	while (ch = *src++) {
		if (ch & 0x80) {
			flag = JNI_FALSE;
			break;
		}
	}

	return flag;
}

char * GetStringUnicodeChars(JNIEnv* env, jstring jsrc, const char * encoding) {
	char* rtn = NULL;

	jclass clazz = (*env)->FindClass(env, "java/lang/String");
	jmethodID methodID = (*env)->GetMethodID(env, clazz, "getBytes", "(Ljava/lang/String;)[B");
	jstring jencoding = (*env)->NewStringUTF(env, encoding);
	jbyteArray jbyte_array = (jbyteArray)(*env)->CallObjectMethod(env, jsrc, methodID, jencoding);

	jsize byte_array_len = (*env)->GetArrayLength(env, jbyte_array);
	jbyte * jbyte_array_ptr = (*env)->GetByteArrayElements(env, jbyte_array, JNI_FALSE);
	if (byte_array_len > 0) {
		rtn = (char*) malloc(byte_array_len + 1);
		memcpy(rtn, jbyte_array_ptr, byte_array_len);
		rtn[byte_array_len] = 0;
	}
	(*env)->ReleaseByteArrayElements(env, jbyte_array, jbyte_array_ptr, 0);

	return rtn;
}

jstring NewStringUnicode(JNIEnv * env, const char * src, const char * encoding) {
	jbyteArray byte_array = (*env)->NewByteArray(env, strlen(src));
	(*env)->SetByteArrayRegion(env, byte_array, 0, strlen(src), (jbyte*) src);
	jstring jencoding = (*env)->NewStringUTF(env, encoding);

	jclass clazz = (*env)->FindClass(env, "java/lang/String");
	jmethodID methodID = (*env)->GetMethodID(env, clazz, "<init>", "([BLjava/lang/String;)V");
	return (jstring)(*env)->NewObject(env, clazz, methodID, byte_array, jencoding);
}
